from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible
import uuid
from django.db import models
from django.conf import settings
# Create your models here.


class Incident(models.Model):
    incidentID = models.OneToOneField(
        on_delete=models.CASCADE, primary_key=True)
    slug = models.UUIDField(default=uuid.uuid4, blank=True, editable=False)
    # Add more user profile fields here. Make sure they are nullable
    # or with default values
    opened = models.CharField("---", max_length=200, blank=True, null=True)
    closed = models.CharField("---", max_length=200, blank=True, null=True)
    reporter = models.CharField("---", max_length=200, blank=True, null=True)
    priority = models.CharField("---", max_length=200, blank=True, null=True)
    status = models.CharField("---", max_length=200, blank=True, null=True)
    description = models.CharField(
        "---", max_length=200, blank=True, null=True)


"""
Create Models for Incident Types:
-Network Attacks / Scanning
-Malware Infection
-Social Engineering
-Access
-Other
"""
