from django.apps import AppConfig


class IncidentsConfig(AppConfig):
    name = 'Incidents'
